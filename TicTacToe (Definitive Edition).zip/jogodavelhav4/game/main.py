from Controller.controller import Controller
from SettingsAndDB.settings import *

class Main:
    # Game entry point
    if __name__ == "__main__":
        controller = Controller()

    # Login screen
    if not controller.login_screen():
        sys.exit()  # Exit if login fails

    # Main menu
    while True:
        controller.main_menu()
        controller.run_game()