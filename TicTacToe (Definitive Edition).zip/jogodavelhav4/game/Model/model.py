from SettingsAndDB.settings import *

# Model (Game data and logic)
class Model:
    def __init__(self):
        self.board = np.zeros((BOARD_ROWS, BOARD_COLS))
        self.player = 1
        self.game_over = False

    def mark_square(self, row, col, player):
        self.board[row][col] = player

    def available_square(self, row, col):
        return self.board[row][col] == 0

    def is_board_full(self):
        return np.all(self.board != 0)

    def check_win(self, player):
        # Check rows
        for row in range(BOARD_ROWS):
            if (
                self.board[row][0] == player
                and self.board[row][1] == player
                and self.board[row][2] == player
            ):
                return True

        # Check columns
        for col in range(BOARD_COLS):
            if (
                self.board[0][col] == player
                and self.board[1][col] == player
                and self.board[2][col] == player
            ):
                return True

        # Check main diagonal
        if (
            self.board[0][0] == player
            and self.board[1][1] == player
            and self.board[2][2] == player
        ):
            return True

        # Check secondary diagonal
        if (
            self.board[2][0] == player
            and self.board[1][1] == player
            and self.board[0][2] == player
        ):
            return True

        return False

    def reset(self):
        self.board = np.zeros((BOARD_ROWS, BOARD_COLS))
        self.player = 1
        self.game_over = False