from SettingsAndDB.settings import *

class Boundary:
    @staticmethod
    def load_users():
        if not os.path.exists(DB_FILE):
            print(f"Dados do usuário não encontrados no {DB_FILE}. Criando um novo...")
            return {}
        try:
            with open(DB_FILE, "r") as file:
                return json.load(file)
        except json.JSONDecodeError:
            print("Deu erro JSON.Resentando os dados do usuário.")
            return {}

    @staticmethod
    def save_users(users):
        try:
            with open(DB_FILE, "w") as file:
                json.dump(users, file)
            print(f"Usuário salvo com sucesso no {DB_FILE}.")
        except Exception as e:
            print(f"Falha em salvar usuários no {DB_FILE}: {e}")

    @staticmethod
    def is_superuser(username):
        users = Boundary.load_users()
        return users.get(username, {}).get("is_superuser", False)