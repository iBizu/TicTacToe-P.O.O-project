from SettingsAndDB.settings import *

# View (Graphical interface)
class View:
    def draw_lines(self):
        screen.fill(BG_COLOR)
        # Horizontal lines
        pygame.draw.line(
            screen, LINE_COLOR, (0, SQUARE_SIZE), (WIDTH, SQUARE_SIZE), LINE_WIDTH
        )
        pygame.draw.line(
            screen,
            LINE_COLOR,
            (0, 2 * SQUARE_SIZE),
            (WIDTH, 2 * SQUARE_SIZE),
            LINE_WIDTH,
        )
        # Vertical lines
        pygame.draw.line(
            screen,
            LINE_COLOR,
            (SQUARE_SIZE, 0),
            (SQUARE_SIZE, HEIGHT - 100),
            LINE_WIDTH,
        )
        pygame.draw.line(
            screen,
            LINE_COLOR,
            (2 * SQUARE_SIZE, 0),
            (2 * SQUARE_SIZE, HEIGHT - 100),
            LINE_WIDTH,
        )

    def draw_figures(self, board):
        for row in range(BOARD_ROWS):
            for col in range(BOARD_COLS):
                if board[row][col] == 1:
                    pygame.draw.circle(
                        screen,
                        CIRCLE_COLOR,
                        (
                            int(col * SQUARE_SIZE + SQUARE_SIZE // 2),
                            int(row * SQUARE_SIZE + SQUARE_SIZE // 2),
                        ),
                        CIRCLE_RADIUS,
                        CIRCLE_WIDTH,
                    )
                elif board[row][col] == 2:
                    pygame.draw.line(
                        screen,
                        CROSS_COLOR,
                        (
                            col * SQUARE_SIZE + SPACE,
                            row * SQUARE_SIZE + SQUARE_SIZE - SPACE,
                        ),
                        (
                            col * SQUARE_SIZE + SQUARE_SIZE - SPACE,
                            row * SQUARE_SIZE + SPACE,
                        ),
                        CROSS_WIDTH,
                    )
                    pygame.draw.line(
                        screen,
                        CROSS_COLOR,
                        (col * SQUARE_SIZE + SPACE, row * SQUARE_SIZE + SPACE),
                        (
                            col * SQUARE_SIZE + SQUARE_SIZE - SPACE,
                            row * SQUARE_SIZE + SQUARE_SIZE - SPACE,
                        ),
                        CROSS_WIDTH,
                    )

    def draw_win_lines(self, model):
        player = model.player
        if model.check_win(player):
            # Draw lines for row wins
            for row in range(BOARD_ROWS):
                if (
                    model.board[row][0] == player
                    and model.board[row][1] == player
                    and model.board[row][2] == player
                ):
                    self.draw_horizontal_win_line(row, player)

            # Draw lines for column wins
            for col in range(BOARD_COLS):
                if (
                    model.board[0][col] == player
                    and model.board[1][col] == player
                    and model.board[2][col] == player
                ):
                    self.draw_vertical_win_line(col, player)

            # Draw line for main diagonal win
            if (
                model.board[0][0] == player
                and model.board[1][1] == player
                and model.board[2][2] == player
            ):
                self.draw_desc_diagonal(player)

            # Draw line for secondary diagonal win
            if (
                model.board[2][0] == player
                and model.board[1][1] == player
                and model.board[0][2] == player
            ):
                self.draw_asc_diagonal(player)

    def draw_horizontal_win_line(self, row, player):
        posY = row * SQUARE_SIZE + SQUARE_SIZE // 2
        color = CIRCLE_COLOR if player == 1 else CROSS_COLOR
        pygame.draw.line(screen, color, (15, posY), (WIDTH - 15, posY), WIN_LINE_WIDTH)

    def draw_vertical_win_line(self, col, player):
        posX = col * SQUARE_SIZE + SQUARE_SIZE // 2
        color = CIRCLE_COLOR if player == 1 else CROSS_COLOR
        pygame.draw.line(
            screen, color, (posX, 15), (posX, HEIGHT - 115), WIN_LINE_WIDTH
        )

    def draw_asc_diagonal(self, player):
        color = CIRCLE_COLOR if player == 1 else CROSS_COLOR
        pygame.draw.line(
            screen, color, (15, HEIGHT - 115), (WIDTH - 15, 15), WIN_LINE_WIDTH
        )

    def draw_desc_diagonal(self, player):
        color = CIRCLE_COLOR if player == 1 else CROSS_COLOR
        pygame.draw.line(
            screen, color, (15, 15), (WIDTH - 15, HEIGHT - 115), WIN_LINE_WIDTH
        )

    def draw_restart_button(self):
        button_rect = pygame.Rect(WIDTH // 4, HEIGHT - 110, WIDTH // 2, 50)
        pygame.draw.rect(screen, BUTTON_COLOR, button_rect)
        font = pygame.font.Font(None, 36)
        text = font.render("Reiniciar", True, BUTTON_TEXT_COLOR)
        text_rect = text.get_rect(center=button_rect.center)
        screen.blit(text, text_rect)
        return button_rect

    def draw_back_to_menu_button(self):
        button_rect = pygame.Rect(WIDTH // 4, HEIGHT - 55, WIDTH // 2, 50)
        pygame.draw.rect(screen, BUTTON_COLOR, button_rect)
        font = pygame.font.Font(None, 36)
        text = font.render("Voltar ao Menu", True, BUTTON_TEXT_COLOR)
        text_rect = text.get_rect(center=button_rect.center)
        screen.blit(text, text_rect)
        return button_rect

    def draw_logout_button(self):
        button_rect = pygame.Rect(WIDTH // 4, HEIGHT - 170, WIDTH // 2, 50)
        pygame.draw.rect(screen, BUTTON_COLOR, button_rect)
        font = pygame.font.Font(None, 36)
        text = font.render("Logout", True, BUTTON_TEXT_COLOR)
        text_rect = text.get_rect(center=button_rect.center)
        screen.blit(text, text_rect)
        return button_rect

    def draw_menu(self):
        screen.fill(BG_COLOR)
        font_title = pygame.font.Font(None, 48)
        font_button = pygame.font.Font(None, 36)

        # Draw the title centered
        title_text = font_title.render("Escolha a dificuldade", True, BUTTON_TEXT_COLOR)
        title_rect = title_text.get_rect(center=(WIDTH // 2, 50))
        screen.blit(title_text, title_rect)

        # Position the buttons lower so they don't overlap the board
        easy_button = pygame.Rect(WIDTH // 4, 100, WIDTH // 2, 50)
        medium_button = pygame.Rect(WIDTH // 4, 170, WIDTH // 2, 50)
        impossible_button = pygame.Rect(WIDTH // 4, 240, WIDTH // 2, 50)
        profile_button = pygame.Rect(
            WIDTH // 4, 330, WIDTH // 2, 50
        )  # New profile button
        logout_button = pygame.Rect(WIDTH // 4, 400, WIDTH // 2, 50)  # Logout button

        pygame.draw.rect(screen, BUTTON_COLOR, easy_button)
        pygame.draw.rect(screen, BUTTON_COLOR, medium_button)
        pygame.draw.rect(screen, BUTTON_COLOR, impossible_button)
        pygame.draw.rect(screen, BUTTON_COLOR, profile_button)
        pygame.draw.rect(screen, BUTTON_COLOR, logout_button)  # Draw the logout button

        easy_text = font_button.render("Nenem", True, BUTTON_TEXT_COLOR)
        medium_text = font_button.render("Chad", True, BUTTON_TEXT_COLOR)
        impossible_text = font_button.render("Souls", True, BUTTON_TEXT_COLOR)
        profile_text = font_button.render(
            "Perfil", True, BUTTON_TEXT_COLOR
        )  # Profile button text
        logout_text = font_button.render(
            "Logout", True, BUTTON_TEXT_COLOR
        )  # Logout button text

        screen.blit(easy_text, easy_text.get_rect(center=easy_button.center))
        screen.blit(medium_text, medium_text.get_rect(center=medium_button.center))
        screen.blit(
            impossible_text, impossible_text.get_rect(center=impossible_button.center)
        )
        screen.blit(
            profile_text, profile_text.get_rect(center=profile_button.center)
        )  # Blit the profile button text
        screen.blit(
            logout_text, logout_text.get_rect(center=logout_button.center)
        )  # Blit the logout button text

        return (
            easy_button,
            medium_button,
            impossible_button,
            profile_button,
            logout_button,
        )

    def draw_login_screen(self, status_message=None):
        screen.fill(BG_COLOR)
        font = pygame.font.Font(None, 36)

        username_label = font.render("Username:", True, BUTTON_TEXT_COLOR)
        password_label = font.render("Senha:", True, BUTTON_TEXT_COLOR)

        screen.blit(username_label, (WIDTH // 12, HEIGHT // 4))
        screen.blit(password_label, (WIDTH // 5.2, HEIGHT // 4 + 50))

        pygame.draw.rect(
            screen, BUTTON_COLOR, (WIDTH // 14 + 150, HEIGHT // 4, 200, 40)
        )  # Username box
        pygame.draw.rect(
            screen, BUTTON_COLOR, (WIDTH // 14 + 150, HEIGHT // 4 + 50, 200, 40)
        )  # Password box

        pygame.draw.rect(
            screen, BUTTON_COLOR, (WIDTH // 20, HEIGHT // 4 + 150, 170, 50)
        )  # Login button
        pygame.draw.rect(
            screen, BUTTON_COLOR, (WIDTH // 200 + 210, HEIGHT // 4 + 150, 170, 50)
        )  # Register button
        pygame.draw.rect(
            screen, BUTTON_COLOR, (WIDTH // 8, HEIGHT // 4 + 220, 300, 50)
        )  # Exit button

        login_text = font.render("Login", True, BUTTON_TEXT_COLOR)
        register_text = font.render("Registro", True, BUTTON_TEXT_COLOR)
        exit_text = font.render("Encerrar", True, BUTTON_TEXT_COLOR)

        screen.blit(login_text, (WIDTH // 6 + 1, HEIGHT // 4 + 160))
        screen.blit(register_text, (WIDTH // 6 + 180, HEIGHT // 4 + 160))
        screen.blit(exit_text, (WIDTH // 6 + 80, HEIGHT // 4 + 230))

        if status_message:
            status_font = pygame.font.Font(None, 28)
            status_text = status_font.render(status_message, True, ERROR_COLOR)
            screen.blit(status_text, (30, HEIGHT // 4 + 100))  

    def draw_profile_screen(self, username, status_message=None):
        screen.fill(BG_COLOR)
        font = pygame.font.Font(None, 36)

        username_label = font.render("Novo User:", True, BUTTON_TEXT_COLOR)
        password_label = font.render("Nova Senha:", True, BUTTON_TEXT_COLOR)

        screen.blit(username_label, (WIDTH // 7.4, HEIGHT // 4))
        screen.blit(password_label, (WIDTH // 12, HEIGHT // 4 + 50))

        pygame.draw.rect(
            screen, BUTTON_COLOR, (WIDTH // 4 + 85, HEIGHT // 4, 200, 40)
        )  # Username box
        pygame.draw.rect(
            screen, BUTTON_COLOR, (WIDTH // 4 + 85, HEIGHT // 4 + 50, 200, 40)
        )  # Password box

        pygame.draw.rect(
            screen, BUTTON_COLOR, (WIDTH // 12, HEIGHT // 4 + 150, 150, 50)
        )  # Save button
        pygame.draw.rect(
            screen, BUTTON_COLOR, (WIDTH // 12 + 200, HEIGHT // 4 + 150, 150, 50)
        )  # Cancel button
        pygame.draw.rect(
            screen, RED, (WIDTH // 8, HEIGHT // 4 + 220, 300, 50)
        )  # Delete account button

        save_text = font.render("Salvar", True, BUTTON_TEXT_COLOR)
        cancel_text = font.render("Voltar", True, BUTTON_TEXT_COLOR)
        delete_text = font.render("Deletar conta", True, BUTTON_TEXT_COLOR)

        screen.blit(save_text, (WIDTH // 12 + 35, HEIGHT // 4 + 160))
        screen.blit(cancel_text, (WIDTH // 12 + 240, HEIGHT // 4 + 160))
        screen.blit(delete_text, (WIDTH // 8 + 70, HEIGHT // 4 + 230))

        if status_message:
            status_font = pygame.font.Font(None, 28)
            status_text = status_font.render(status_message, True, ERROR_COLOR)
            screen.blit(status_text, (30, HEIGHT // 4 + 100))  

    def draw_confirmation_screen(self):
        screen.fill(BG_COLOR)
        font = pygame.font.Font(None, 36)

        message = font.render("Quer mesmo deletar sua conta?", True, ERROR_COLOR)
        screen.blit(message, (WIDTH // 4 - 50, HEIGHT // 4 + 20))

        confirm_button = pygame.Rect(WIDTH // 4, HEIGHT // 4 + 100, 150, 50)
        cancel_button = pygame.Rect(WIDTH // 2 + 20, HEIGHT // 4 + 100, 150, 50)

        pygame.draw.rect(screen, RED, confirm_button)
        pygame.draw.rect(screen, BUTTON_COLOR, cancel_button)

        confirm_text = font.render("Sim", True, BUTTON_TEXT_COLOR)
        cancel_text = font.render("Não", True, BUTTON_TEXT_COLOR)

        screen.blit(
            confirm_text,
            (
                confirm_button.centerx - confirm_text.get_width() // 2,
                confirm_button.centery - confirm_text.get_height() // 2,
            ),
        )
        screen.blit(
            cancel_text,
            (
                cancel_button.centerx - cancel_text.get_width() // 2,
                cancel_button.centery - cancel_text.get_height() // 2,
            ),
        )

        return confirm_button, cancel_button

    def draw_superuser_menu(self, users, status_message=None, scroll_offset=0):
        screen.fill((255, 255, 255))  # Limpa a tela com fundo branco
        font = pygame.font.Font(None, 36)
        y_offset = 20 + scroll_offset  # Aplicar o deslocamento de scroll
        self.user_rects = {}  # Inicializa o dicionário de retângulos de usuários

    # Desenha cada usuário
        for username, data in users.items():
        # Verifica se 'data' é um dicionário
            if isinstance(data, dict):
                is_superuser = data.get("is_superuser", False)
                user_info = f"{username} - {'Admin' if is_superuser else 'User'}"
            else:
                user_info = f"{username} - (Dados inválidos)"

            text_surface = font.render(user_info, True, (0, 0, 0))
            text_rect = screen.blit(text_surface, (20, y_offset))
            self.user_rects[username] = text_rect  # Salva o retângulo do usuário
            y_offset += 40  # Incrementa a posição para o próximo usuário

    # Exibe mensagem de status, se houver
        if status_message:
            status_font = pygame.font.Font(None, 28)
            status_text = status_font.render(status_message, True, (255, 0, 0))
            screen.blit(status_text, (20, y_offset + 20))

    # Desenha o botão de logout
        logout_button = pygame.Rect(WIDTH // 4, HEIGHT - 55, WIDTH // 2, 50)
        pygame.draw.rect(screen, (0, 255, 0), logout_button)
        text = font.render("Logout", True, (255, 255, 255))
        text_rect = text.get_rect(center=logout_button.center)
        screen.blit(text, text_rect)

        self.logout_button_rect = logout_button  # Armazena o retângulo do botão de logout
        pygame.display.update()
    
    def draw_confirmation_screen(self, selected_user):
        screen.fill((255, 255, 255))
        font = pygame.font.Font(None, 36)

        message = font.render(f"Deletar {selected_user}?", True, (255, 0, 0))
        screen.blit(message, (WIDTH // 4 - 50, HEIGHT // 4 + 20))

        confirm_button = pygame.Rect(WIDTH // 8, HEIGHT // 4 + 100, 150, 50)
        cancel_button = pygame.Rect(WIDTH // 2 + 20, HEIGHT // 4 + 100, 150, 50)

        pygame.draw.rect(screen, (255, 0, 0), confirm_button)
        pygame.draw.rect(screen, (0, 255, 0), cancel_button)

        confirm_text = font.render("Sim", True, (255, 255, 255))
        cancel_text = font.render("Não", True, (255, 255, 255))

        screen.blit(
            confirm_text,
            (
                confirm_button.centerx - confirm_text.get_width() // 2,
                confirm_button.centery - confirm_text.get_height() // 2,
            ),
        )
        screen.blit(
            cancel_text,
            (
                cancel_button.centerx - cancel_text.get_width() // 2,
                cancel_button.centery - cancel_text.get_height() // 2,
            ),
        )

        pygame.display.update()

        return confirm_button, cancel_button

    def check_delete_user_click(self, pos):
        # Verifica se o clique foi em algum dos retângulos de usuários
        for username, rect in self.user_rects.items():
            if rect.collidepoint(pos):
                self.selected_user = username
                return True
        return False

    def get_selected_user(self):
        # Retorna o usuário selecionado, se houver
        return self.selected_user

    def check_logout_click(self, pos):
        # Verifica se o clique foi no botão de logout
        return self.logout_button_rect.collidepoint(pos)

    def draw_edit_user_screen(self, selected_user):
        screen.fill((255, 255, 255))
        font = pygame.font.Font(None, 36)

        message = font.render(f"Editar o nome do(a) {selected_user}", True, (0, 0, 0))
        screen.blit(message, (WIDTH // 4 - 65, HEIGHT // 4 + 20))

        # Campo de texto para edição do nome
        input_box = pygame.Rect(WIDTH // 8, HEIGHT // 4 + 100, 300, 50)
        pygame.draw.rect(screen, (0, 0, 0), input_box, 2)

        confirm_button = pygame.Rect(WIDTH // 8, HEIGHT // 4 + 180, 150, 50)
        cancel_button = pygame.Rect(WIDTH // 2 + 20, HEIGHT // 4 + 180, 150, 50)

        pygame.draw.rect(screen, (0, 255, 0), confirm_button)
        pygame.draw.rect(screen, (255, 0, 0), cancel_button)

        confirm_text = font.render("Salvar", True, (255, 255, 255))
        cancel_text = font.render("Voltar", True, (255, 255, 255))

        screen.blit(
            confirm_text,
            (
                confirm_button.centerx - confirm_text.get_width() // 2,
                confirm_button.centery - confirm_text.get_height() // 2,
            ),
        )
        screen.blit(
            cancel_text,
            (
                cancel_button.centerx - cancel_text.get_width() // 2,
                cancel_button.centery - cancel_text.get_height() // 2,
            ),
        )

        pygame.display.update()

        return input_box, confirm_button, cancel_button

    def draw_status_message(self, message, color=(255, 0, 0)):
        font = pygame.font.Font(None, 28)
        status_text = font.render(message, True, color)
        screen.blit(status_text, (WIDTH // 4, HEIGHT // 4 + 250))
        pygame.display.update()

    def draw_user_options(self, selected_user):
        screen.fill((255, 255, 255))
        font = pygame.font.Font(None, 36)

        message = font.render(f"Opções para {selected_user}:", True, (0, 0, 0))
        screen.blit(message, (WIDTH // 4 - 50, HEIGHT // 4 + 20))

        # Botão para editar o nome do usuário
        edit_button = pygame.Rect(WIDTH // 8, HEIGHT // 4 + 100, 150, 50)
        pygame.draw.rect(screen, (0, 255, 0), edit_button)
        edit_text = font.render("Editar Nome", True, (255, 255, 255))
        screen.blit(
            edit_text,
            (
                edit_button.centerx - edit_text.get_width() // 2,
                edit_button.centery - edit_text.get_height() // 2,
            ),
        )

        # Botão para excluir o usuário
        delete_button = pygame.Rect(WIDTH // 2 + 20, HEIGHT // 4 + 100, 170, 50)
        pygame.draw.rect(screen, (255, 0, 0), delete_button)
        delete_text = font.render("Deletar Conta", True, (255, 255, 255))
        screen.blit(
            delete_text,
            (
                delete_button.centerx - delete_text.get_width() // 2,
                delete_button.centery - delete_text.get_height() // 2,
            ),
        )

        pygame.display.update()

        return edit_button, delete_button

    # Mantém as outras funções da View já definidas anteriormente
