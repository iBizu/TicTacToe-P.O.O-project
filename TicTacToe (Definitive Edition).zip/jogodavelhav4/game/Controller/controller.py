from SettingsAndDB.settings import *
from Boundary.bondary import Boundary
from Model.model import Model
from View.view import View

# Controller (Controle de eventos e lógica do jogo)
class Controller:
    def __init__(self):
        self.model = Model()
        self.view = View()
        self.difficulty = None
        self.menu_active = True
        self.restart_button_rect = None
        self.back_to_menu_button_rect = None
        self.profile_button_rect = None
        self.logout_button_rect = None
        self.username = None  
        self.scroll_offset = 0  
        self.max_scroll = 0  

    def authenticate(self, username, password):
        users = Boundary.load_users()
        return username in users and users[username]["password"] == password

    def register_user(self, username, password):
        users = Boundary.load_users()  # Carrega os usuários do banco de dados JSON

        # Verifica se já existe algum usuário
        if username in users:
            return False  # Usuário já existe

        # Se não houver usuários no sistema, o primeiro será um superusuário
        is_superuser = len(users) == 0  # Primeiro usuário será superusuário

        # Adiciona o novo usuário
        users[username] = {
            "password": password,
            "is_superuser": is_superuser,  # Define se é superusuário (True para o primeiro)
        }

        Boundary.save_users(users)  # Salva os usuários no arquivo JSON
        return True

    def update_user(self, old_username, new_username, new_password):
        users = Boundary.load_users()

        # Verificar se o novo username já existe e se é diferente do username antigo
        if new_username in users and new_username != old_username:
            return False  # Novo nome de usuário já existe

        # Manter os dados existentes do usuário antigo
        user_data = users.pop(old_username)

        # Atualizar o nome e a senha, mantendo os outros dados (como o campo 'is_superuser')
        users[new_username] = {
            "password": new_password,
            "is_superuser": user_data.get("is_superuser", False)  # Mantém o status de superusuário
    }

        # Salvar as alterações no banco de dados
        Boundary.save_users(users)

        # Atualizar o nome de usuário atual do sistema
        self.username = new_username

        return True


    def delete_user(self, username):
        users = Boundary.load_users()
        if username in users:
            users.pop(username)
            Boundary.save_users(users)
            return True
        return False

    def login_screen(self):
        username = ""
        password = ""
        input_active = None
        status_message = None  # Armazena a mensagem de erro ou sucesso
        max_chars = 8  # Limite de caracteres para username e password

        while True:
            # Desenha a tela de login com mensagem de status (se houver)
            self.view.draw_login_screen(status_message)

            font = pygame.font.Font(None, 36)

            # Ajuste para posicionar o texto digitado corretamente
            username_text = font.render(username, True, BG_COLOR)
            password_text = font.render('*' * len(password), True, BG_COLOR)

            # Define margens e espaços ajustados para centralizar os campos de texto
            username_rect_x = WIDTH // 4 + 100  # Mantido conforme solicitado
            password_rect_x = WIDTH // 4 + 100  # Mantido conforme solicitado
            text_y_offset = 10

            # Renderiza o texto digitado dentro das caixas de input
            screen.blit(username_text, (username_rect_x, HEIGHT // 4 + text_y_offset))
            screen.blit(password_text, (password_rect_x, HEIGHT // 4 + 60 + text_y_offset))

            pygame.display.update()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

                if event.type == pygame.MOUSEBUTTONDOWN:
                    # Verifica se o clique foi no campo de username
                    if WIDTH // 4 + 100 <= event.pos[0] <= WIDTH // 4 + 400 and HEIGHT // 4 <= event.pos[1] <= HEIGHT // 4 + 40:
                        input_active = 'username'
                    # Verifica se o clique foi no campo de senha
                    elif WIDTH // 4 + 100 <= event.pos[0] <= WIDTH // 4 + 400 and HEIGHT // 4 + 50 <= event.pos[1] <= HEIGHT // 4 + 90:
                        input_active = 'password'

                    # Verifica se o clique foi no botão de login
                    elif WIDTH // 4 - 110 <= event.pos[0] <= WIDTH // 4 + 90 and HEIGHT // 4 + 150 <= event.pos[1] <= HEIGHT // 4 + 200:
                        if username == "" or password == "":
                            status_message = "Campo não pode estar vazio!"
                        elif self.authenticate(username, password):
                            self.username = username
                            if Boundary.is_superuser(username):
                                self.superuser_menu()  # Menu de superusuário
                            else:
                                return True  # Login bem-sucedido para usuários normais
                        else:
                            status_message = "Login falhou!"

                    # Verifica se o clique foi no botão de registro
                    elif WIDTH // 4 + 110 <= event.pos[0] <= WIDTH // 4 + 310 and HEIGHT // 4 + 150 <= event.pos[1] <= HEIGHT // 4 + 200:
                        if username == "" or password == "":
                            status_message = "Campo não pode estar vazio!"
                        elif self.register_user(username, password):
                            status_message = "Registrado com sucesso!"
                        else:
                            status_message = "Username já existe!"
                    
                    # Verifica se o clique foi no botão de saída
                    exit_button_width = 300
                    exit_button_x = (WIDTH - exit_button_width) // 2
                    if exit_button_x <= event.pos[0] <= exit_button_x + exit_button_width and HEIGHT // 4 + 220 <= event.pos[1] <= HEIGHT // 4 + 270:
                        pygame.quit()
                        sys.exit()

                if event.type == pygame.KEYDOWN:
                    if input_active == 'username':
                        if event.key == pygame.K_BACKSPACE:
                            username = username[:-1]
                        elif len(username) < max_chars:  # Limita o número de caracteres
                            username += event.unicode
                    elif input_active == 'password':
                        if event.key == pygame.K_BACKSPACE:
                            password = password[:-1]
                        elif len(password) < max_chars:  # Limita o número de caracteres
                            password += event.unicode



    def handle_user_deletion(self, confirm_button, cancel_button, selected_user, users):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

                if event.type == pygame.MOUSEBUTTONDOWN:
                    # Verifica se o clique foi no botão de confirmação ("Yes")
                    if confirm_button.collidepoint(event.pos):
                        del users[selected_user]  # Exclui o usuário do dicionário
                        Boundary.save_users(
                            users
                        )  # Salva as mudanças no banco de dados
                        return  # Após excluir, retorna ao menu de superusuário

                    # Verifica se o clique foi no botão de cancelamento ("No")
                    elif cancel_button.collidepoint(event.pos):
                        return  # Cancela a exclusão e retorna ao menu de superusuário

    
    def profile_screen(self):
        new_username = self.username
        new_password = ""
        input_active = None
        status_message = None  # Armazena a mensagem de erro ou sucesso
        max_chars = 8  # Limite de caracteres para username e password

        while True:
            # Chama a função para desenhar a tela do perfil
            self.view.draw_profile_screen(new_username, status_message)

            # Desenha os campos de texto para username e password
            font = pygame.font.Font(None, 36)

            # Ajustando a posição do texto 130 pixels mais à direita
            username_text = font.render(new_username, True, BG_COLOR)
            password_text = font.render('*' * len(new_password), True, BG_COLOR)

            # Ajuste a posição horizontal dos campos de texto 130 pixels mais à direita
            screen.blit(username_text, (WIDTH // 5 + 130, HEIGHT // 4 + 10))  # 130 pixels mais à direita
            screen.blit(password_text, (WIDTH // 5 + 130, HEIGHT // 4 + 60))  # 130 pixels mais à direita

            pygame.display.update()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

                if event.type == pygame.MOUSEBUTTONDOWN:
                    # Verifica se o usuário clicou no campo de entrada de username ou password
                    if WIDTH // 5 + 130 <= event.pos[0] <= WIDTH // 5 + 330 and HEIGHT // 4 <= event.pos[1] <= HEIGHT // 4 + 40:
                        input_active = 'username'
                    elif WIDTH // 5 + 130 <= event.pos[0] <= WIDTH // 5 + 330 and HEIGHT // 4 + 50 <= event.pos[1] <= HEIGHT // 4 + 90:
                        input_active = 'password'
                
                    # Verifica se o usuário clicou no botão de salvar
                    if WIDTH // 12 <= event.pos[0] <= WIDTH // 12 + 150 and HEIGHT // 4 + 150 <= event.pos[1] <= HEIGHT // 4 + 200:
                        if new_username == "" or new_password == "":
                            status_message = "Campos não podem estar vazios!"
                        elif self.update_user(self.username, new_username, new_password):
                            status_message = "Perfil atualizado!"
                        else:
                            status_message = "Username já existe!"
                
                    # Verifica se o usuário clicou no botão de cancelar
                    if WIDTH // 12 + 200 <= event.pos[0] <= WIDTH // 12 + 350 and HEIGHT // 4 + 150 <= event.pos[1] <= HEIGHT // 4 + 200:
                        return  # Cancelar e retornar ao menu principal
                
                    # Verifica se o usuário clicou no botão de exclusão da conta
                    if WIDTH // 8 <= event.pos[0] <= WIDTH // 8 + 300 and HEIGHT // 4 + 220 <= event.pos[1] <= HEIGHT // 4 + 270:
                        # Mostrar diálogo de confirmação para excluir a conta
                        if self.confirm_deletion():
                            if self.delete_user(self.username):
                                status_message = "Deletado com sucesso!"
                                self.username = None
                                return self.login_screen()  # Volta para a tela de login após a exclusão
                            else:
                                status_message = "Falha em deletar!"

            # Processa entradas de teclado para atualizar nome de usuário e senha com limite de caracteres
                if event.type == pygame.KEYDOWN:
                    if input_active == 'username':
                        if event.key == pygame.K_BACKSPACE:
                            new_username = new_username[:-1]
                        elif len(new_username) < max_chars:  # Limita o número de caracteres
                            new_username += event.unicode
                    elif input_active == 'password':
                        if event.key == pygame.K_BACKSPACE:
                            new_password = new_password[:-1]
                        elif len(new_password) < max_chars:  # Limita o número de caracteres
                            new_password += event.unicode


    def superuser_menu(self):
        status_message = None
        while True:
            users = Boundary.load_users()
            self.view.draw_superuser_menu(users, status_message, self.scroll_offset)

        # Atualiza o valor máximo de scroll com base no número de usuários
            total_users_height = len(users) * 40  # Altura ocupada por cada usuário
            self.max_scroll = max(0, total_users_height - HEIGHT + 100)

            pygame.display.update()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

            # Controle de scroll pelo mouse (usando a roda)
                if event.type == pygame.MOUSEWHEEL:
                    if event.y > 0:  # Scroll para cima
                        self.scroll_offset += 40
                    elif event.y < 0:  # Scroll para baixo
                        self.scroll_offset -= 40

                # Limitar o scroll dentro do intervalo permitido
                    self.scroll_offset = max(-self.max_scroll, min(0, self.scroll_offset))

            # Controle de scroll pelas teclas de seta
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_DOWN:
                        self.scroll_offset -= 40
                    elif event.key == pygame.K_UP:
                        self.scroll_offset += 40

                # Limitar o scroll dentro do intervalo permitido
                    self.scroll_offset = max(-self.max_scroll, min(0, self.scroll_offset))

            # Verifica apenas cliques com o botão esquerdo do mouse
                if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:  # Botão 1 é o botão esquerdo do mouse
                # Verifica se o clique foi em um usuário
                    if self.view.check_delete_user_click(event.pos):
                        selected_user = self.view.get_selected_user()

                    # Impede que o administrador exclua ou edite a si mesmo
                        if selected_user == self.username:
                            status_message = (
                                "Admin não pode ser modificado!"
                            )
                        else:
                        # Exibe as opções de "Editar" e "Excluir"
                            edit_button, delete_button = self.view.draw_user_options(
                                selected_user
                            )
                            self.handle_user_options(
                                edit_button, delete_button, selected_user, users
                            )

                # Verifica se o clique foi no botão de logout
                    elif self.view.check_logout_click(event.pos):
                        return  # Volta para a tela de login

    def handle_user_options(self, edit_button, delete_button, selected_user, users):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

                if event.type == pygame.MOUSEBUTTONDOWN:
                    # Verifica se o clique foi no botão de edição
                    if edit_button.collidepoint(event.pos):
                        self.edit_user(selected_user, users)
                        return  # Volta ao menu do superusuário após edição

                    # Verifica se o clique foi no botão de exclusão
                    elif delete_button.collidepoint(event.pos):
                        # Pergunta ao administrador se ele deseja excluir o usuário
                        confirm_button, cancel_button = (
                            self.view.draw_confirmation_screen(selected_user)
                        )
                        self.handle_user_deletion(
                            confirm_button, cancel_button, selected_user, users
                        )
                        return  # Volta ao menu do superusuário após exclusão


    def edit_user(self, selected_user, users):
        input_box, confirm_button, cancel_button = self.view.draw_edit_user_screen(selected_user)
        new_username = ""
        status_message = None
        max_chars = 8  # Limite de caracteres para o nome de usuário

        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_BACKSPACE:
                        new_username = new_username[:-1]
                    elif len(new_username) < max_chars:  # Aplica o limite de caracteres
                        new_username += event.unicode

                # Desenha o novo nome conforme ele é digitado
                self.view.draw_edit_user_screen(selected_user)
                font = pygame.font.Font(None, 36)
                input_surface = font.render(new_username, True, (0, 0, 0))
                screen.blit(input_surface, (input_box.x + 10, input_box.y + 10))
                pygame.display.update()

                if event.type == pygame.MOUSEBUTTONDOWN:
                    # Verifica se o clique foi no botão de confirmação
                    if confirm_button.collidepoint(event.pos):
                        if new_username in users:
                            status_message = "Username já existe!"
                            self.view.draw_status_message(status_message, (255, 0, 0))
                        elif new_username.strip() == "":
                            status_message = "Campo não pode estar vazio!"
                            self.view.draw_status_message(status_message, (255, 0, 0))
                        else:
                            # Atualiza o nome de usuário
                            users[new_username] = users.pop(selected_user)
                            Boundary.save_users(users)
                            status_message = "Username atualizado com sucesso!"
                            self.view.draw_status_message(status_message, (0, 255, 0))
                            return  # Volta ao menu do superusuário

                    # Verifica se o clique foi no botão de cancelamento
                    elif cancel_button.collidepoint(event.pos):
                        return  # Apenas retorna ao menu de superusuário sem editar

                    # Verifica se o clique foi no botão de cancelamento
                    elif cancel_button.collidepoint(event.pos):
                        return  # Apenas retorna ao menu de superusuário sem editar

    def confirm_deletion(self):
    # Passando o nome do usuário como argumento para draw_confirmation_screen
        confirm_button, cancel_button = self.view.draw_confirmation_screen(
            self.username
        )
        pygame.display.update()

        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

                if event.type == pygame.MOUSEBUTTONDOWN:
                # Verifica se o clique foi no botão de confirmação ajustado
                    if confirm_button.collidepoint(event.pos):
                        return True  # Confirm deletion
                # Verifica se o clique foi no botão de cancelamento ajustado
                    elif cancel_button.collidepoint(event.pos):
                        return False  


    def main_menu(self):
        self.menu_active = True
        while self.menu_active:
            (
                easy_button,
                medium_button,
                impossible_button,
                profile_button,
                logout_button,
            ) = self.view.draw_menu()
        
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                # Verifica se o clique foi no botão de dificuldade "Nenem"
                    if easy_button.collidepoint(event.pos):
                        self.difficulty = "Nenem"
                        self.menu_active = False
                # Verifica se o clique foi no botão de dificuldade "Chad"
                    elif medium_button.collidepoint(event.pos):
                        self.difficulty = "Chad"
                        self.menu_active = False
                # Verifica se o clique foi no botão de dificuldade "Souls"
                    elif impossible_button.collidepoint(event.pos):
                        self.difficulty = "Souls"
                        self.menu_active = False
                # Verifica se o clique foi no botão de perfil ajustado
                    elif profile_button.collidepoint(event.pos):
                        self.profile_screen()  
                # Verifica se o clique foi no botão de logout ajustado
                    elif logout_button.collidepoint(event.pos):
                        self.menu_active = True
                        self.login_screen()  

            pygame.display.update()


    def run_game(self):
        self.model.reset()
        self.view.draw_lines()

        if self.difficulty == "Nenem":
            best_move_function = self.easy_move
        elif self.difficulty == "Chad":
            best_move_function = self.medium_move
        elif self.difficulty == "Souls":
            best_move_function = self.impossible_move

        while not self.menu_active:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

                if event.type == pygame.MOUSEBUTTONDOWN and not self.model.game_over:
                    mouseX = event.pos[0]
                    mouseY = event.pos[1]

                    clicked_row = mouseY // SQUARE_SIZE
                    clicked_col = mouseX // SQUARE_SIZE

                    if (
                        clicked_row < BOARD_ROWS
                        and clicked_col < BOARD_COLS
                        and self.model.available_square(clicked_row, clicked_col)
                    ):
                        self.model.mark_square(
                            clicked_row, clicked_col, self.model.player
                        )
                        self.view.draw_figures(self.model.board)
                        if self.model.check_win(self.model.player):
                            self.view.draw_win_lines(self.model)
                            self.model.game_over = True
                            self.restart_button_rect = self.view.draw_restart_button()
                            self.back_to_menu_button_rect = (
                                self.view.draw_back_to_menu_button()
                            )
                        elif self.model.is_board_full():
                            self.model.game_over = True
                            self.restart_button_rect = self.view.draw_restart_button()
                            self.back_to_menu_button_rect = (
                                self.view.draw_back_to_menu_button()
                            )
                        else:
                            self.model.player = 2

                if self.model.player == 2 and not self.model.game_over:
                    move = best_move_function()
                    if move is not None:
                        row, col = move
                        self.model.mark_square(row, col, self.model.player)
                        self.view.draw_figures(self.model.board)
                        if self.model.check_win(self.model.player):
                            self.view.draw_win_lines(self.model)
                            self.model.game_over = True
                            self.restart_button_rect = self.view.draw_restart_button()
                            self.back_to_menu_button_rect = (
                                self.view.draw_back_to_menu_button()
                            )
                        elif self.model.is_board_full():
                            self.model.game_over = True
                            self.restart_button_rect = self.view.draw_restart_button()
                            self.back_to_menu_button_rect = (
                                self.view.draw_back_to_menu_button()
                            )
                        else:
                            self.model.player = 1

                if self.model.game_over and event.type == pygame.MOUSEBUTTONDOWN:
                    if self.check_restart_click(event.pos, self.restart_button_rect):
                        self.model.reset()
                        self.view.draw_lines()
                    elif self.check_back_to_menu_click(
                        event.pos, self.back_to_menu_button_rect
                    ):
                        self.menu_active = True
                        return  

            pygame.display.update()

    def easy_move(self):
        available_moves = [
            (row, col)
            for row in range(BOARD_ROWS)
            for col in range(BOARD_COLS)
            if self.model.available_square(row, col)
        ]
        if available_moves:
            return random.choice(available_moves)
        return None

    def medium_move(self):
        best_score = -np.inf
        move = None
        for row in range(BOARD_ROWS):
            for col in range(BOARD_COLS):
                if self.model.available_square(row, col):
                    self.model.board[row][col] = 2
                    score = self.minimax(self.model.board, 0, False)
                    self.model.board[row][col] = 0
                    if score > best_score:
                        best_score = score
                        move = (row, col)
        return move

    def impossible_move(self):
        return self.medium_move()

    def minimax(self, board, depth, is_maximizing):
        if self.model.check_win(2):
            return 1
        elif self.model.check_win(1):
            return -1
        elif self.model.is_board_full():
            return 0

        if is_maximizing:
            best_score = -np.inf
            for row in range(BOARD_ROWS):
                for col in range(BOARD_COLS):
                    if self.model.available_square(row, col):
                        board[row][col] = 2
                        score = self.minimax(board, depth + 1, False)
                        board[row][col] = 0
                        best_score = max(score, best_score)
            return best_score
        else:
            best_score = np.inf
            for row in range(BOARD_ROWS):
                for col in range(BOARD_COLS):
                    if self.model.available_square(row, col):
                        board[row][col] = 1
                        score = self.minimax(board, depth + 1, True)
                        board[row][col] = 0
                        best_score = min(score, best_score)
            return best_score

    def check_restart_click(self, pos, button_rect):
        return button_rect and button_rect.collidepoint(pos)

    def check_back_to_menu_click(self, pos, button_rect):
        return button_rect and button_rect.collidepoint(pos)