import json
import os
import pygame
import sys
import numpy as np
import random

# Initialize pygame
pygame.init()

# Screen settings
WIDTH, HEIGHT = 400, 500
LINE_WIDTH = 15
WIN_LINE_WIDTH = 15
BOARD_ROWS = 3
BOARD_COLS = 3
SQUARE_SIZE = WIDTH // BOARD_COLS
CIRCLE_RADIUS = SQUARE_SIZE // 3
CIRCLE_WIDTH = 15
CROSS_WIDTH = 25
SPACE = SQUARE_SIZE // 4

# Colors
RED = (255, 0, 0)
BG_COLOR = (28, 170, 156)
LINE_COLOR = (23, 145, 135)
CIRCLE_COLOR = (239, 231, 200)
CROSS_COLOR = (66, 66, 66)
BUTTON_COLOR = (0, 255, 0)
BUTTON_TEXT_COLOR = (255, 255, 255)
ERROR_COLOR = (255, 0, 0)

# Diretório para armazenar dados
DATA_DIR = os.path.join(os.path.dirname(__file__), "data")

# Cria a pasta data se ela não existir
if not os.path.exists(DATA_DIR):
    os.makedirs(DATA_DIR)

# Caminho para o arquivo users.json dentro da pasta data
DB_FILE = os.path.join(DATA_DIR, "users.json")

# Game screen
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Jogo da Velha")

